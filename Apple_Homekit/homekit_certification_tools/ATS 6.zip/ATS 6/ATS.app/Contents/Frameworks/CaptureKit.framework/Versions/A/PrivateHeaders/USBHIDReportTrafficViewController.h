//
//  USBHIDReportTrafficViewController.h
//  ATSMacApp
//
//  Created by Bob Burrough on 12/12/12.
//  Copyright (c) 2012 Apple Inc. All rights reserved.
//

#import <CaptureKit/TrafficViewController.h>

@interface USBHIDReportTrafficViewController : TrafficViewController

@end
