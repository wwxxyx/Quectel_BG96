//
//  CarPlayBonjourServiceInstanceEvent.h
//  ATSMacApp
//
//  Created by Vinod Madigeri on 10/16/17.
//  Copyright © 2017 Apple Inc. All rights reserved.
//

#import <CaptureKit/BonjourServiceInstanceEvent.h>

@interface CarPlayBonjourServiceInstanceEvent : BonjourServiceInstanceEvent

@end
