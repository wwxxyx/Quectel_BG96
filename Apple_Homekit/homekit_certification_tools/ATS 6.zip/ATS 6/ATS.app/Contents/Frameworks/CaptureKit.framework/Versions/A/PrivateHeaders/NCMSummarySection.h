//
//  NCMSummarySection.h
//  ATSMacApp
//
//  Created by Mark Hamlin on 5/20/13.
//  Copyright (c) 2013 Apple Inc. All rights reserved.
//

#import <CaptureKit/SummarySection.h>

@interface NCMSummarySection : SummarySection

@end
