//
//  HIDGetReportDescriptorEvent.h
//  ATSMacApp
//
//  Created by Zachary Church on 3/17/16.
//  Copyright © 2016 Apple Inc. All rights reserved.
//

#import <CaptureKit/HIDEvent.h>

@interface HIDGetReportDescriptorEvent : HIDEvent

@end
