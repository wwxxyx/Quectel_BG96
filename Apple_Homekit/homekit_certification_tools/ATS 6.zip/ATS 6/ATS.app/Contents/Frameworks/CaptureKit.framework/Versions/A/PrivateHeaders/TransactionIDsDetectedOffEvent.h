//
//  TransactionIDsDetectedOffEvent.h
//  ATSMacApp
//
//  Created by Mark Hamlin on 7/23/12.
//  Copyright (c) 2012 Apple Inc. All rights reserved.
//

#import <CaptureKit/CaptureEvent.h>

@interface TransactionIDsDetectedOffEvent : CaptureEvent

@end
