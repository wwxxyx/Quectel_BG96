//
//  NCMEvent.h
//  ATSMacApp
//
//  Created by Mark Hamlin on 5/21/13.
//  Copyright (c) 2013 Apple Inc. All rights reserved.
//

#import <CaptureKit/CaptureEvent+ReportAnalyzer.h>

@interface NCMEvent : CaptureEvent

@end
