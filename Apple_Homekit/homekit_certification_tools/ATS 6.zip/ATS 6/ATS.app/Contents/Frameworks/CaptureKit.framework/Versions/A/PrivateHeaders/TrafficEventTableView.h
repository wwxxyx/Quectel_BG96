//
//  TrafficEventTableView.h
//  ATSMacApp
//
//  Created by Mark Hamlin on 7/21/11.
//  Copyright 2011 Apple Inc. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface TrafficEventTableView : NSTableView {
}

@end
