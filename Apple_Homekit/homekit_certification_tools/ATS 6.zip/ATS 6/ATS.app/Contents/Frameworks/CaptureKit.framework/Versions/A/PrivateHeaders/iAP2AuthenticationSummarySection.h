//
//  iAP2AuthenticationSummarySection.h
//  ATSMacApp
//
//  Created by Mark Hamlin on 8/17/12.
//  Copyright (c) 2012 Apple Inc. All rights reserved.
//

#import <CaptureKit/SummarySection.h>

@interface iAP2AuthenticationSummarySection : SummarySection

@end
