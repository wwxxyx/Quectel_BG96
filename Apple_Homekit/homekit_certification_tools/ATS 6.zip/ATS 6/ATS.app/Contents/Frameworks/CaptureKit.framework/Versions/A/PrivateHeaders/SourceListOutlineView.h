//
//  SourceListOutlineView.h
//  ATS
//
//  Created by Joe Basu on 2/24/09.
//  Copyright © 2009 Apple Inc. All Rights Reserved.
//

#import <Cocoa/Cocoa.h>

@interface SourceListOutlineView : NSOutlineView {
}

@end
