//
//  NetworkTrafficSummarySection.h
//  ATSMacApp
//
//  Created by Mark Hamlin on 5/16/13.
//  Copyright (c) 2013 Apple Inc. All rights reserved.
//

#import <CaptureKit/SummarySection.h>

@interface NetworkTrafficSummarySection : SummarySection

@end
