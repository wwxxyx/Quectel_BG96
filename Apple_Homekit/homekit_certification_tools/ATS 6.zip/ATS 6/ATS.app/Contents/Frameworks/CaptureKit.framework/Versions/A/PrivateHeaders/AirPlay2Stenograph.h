//
//  AirPlay2Stenograph.h
//  ATSMacApp
//
//  Created by Vinod Madigeri on 7/24/18.
//  Copyright © 2018 Apple Inc. All rights reserved.
//

#import <CaptureKit/CaptureRuleStenograph.h>

@interface AirPlay2Stenograph : CaptureRuleStenograph

@end
