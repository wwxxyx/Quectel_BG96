//
//  TrafficAnnotationView.h
//  ATSMacApp
//
//  Created by Mark Hamlin on 7/28/11.
//  Copyright 2011 Apple Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TrafficAnnotationView : NSView

@end
