//
//  DetailsHeaderView.h
//  ATS
//
//  Created by Joel Levin on 8/31/09.
//  Copyright 2009 Apple Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface DetailsHeaderView : NSView {
    NSGradient *_backgroundGradient;
}

@end
