//
//  ATFR3CaptureDeviceManager.h
//  ATSMacApp
//
//  Created by Vinod Madigeri on 8/9/16.
//  Copyright © 2016 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ATSSerialCaptureDeviceManager.h"

@interface ATFR3CaptureDeviceManager : ATSSerialCaptureDeviceManager

@end
