//
//  iAP2FileTransferTrafficViewController.m
//  ATSMacApp
//
//  Created by Edgard Lima on 27/06/18.
//  Copyright © 2018 Apple Inc. All rights reserved.
//

#import <CaptureKit/ReportAnalyzerBridgeTrafficViewController.h>

@interface iAP2FileTransferTrafficViewController : ReportAnalyzerBridgeTrafficViewController

+ (instancetype)viewController;

@end
