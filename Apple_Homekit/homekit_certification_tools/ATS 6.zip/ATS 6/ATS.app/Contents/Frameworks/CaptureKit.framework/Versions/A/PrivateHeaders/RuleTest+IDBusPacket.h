//
//  RuleTest+IDBusPacket.h
//  ATSMacApp
//
//  Created by anchor on 3/1/13.
//  Copyright (c) 2013 Apple Inc. All rights reserved.
//

#import <CaptureKit/RuleTests.h>

@interface RuleTest_IDBusPacket : NSObject

@end
