//
//  ATSUSBHostDisconnectEvent.h
//  ATSMacApp
//
//  Created by Zachary Church on 1/5/16.
//  Copyright © 2016 Apple Inc. All rights reserved.
//

#import <CaptureKit/USBEvent.h>

@interface ATSUSBHostDisconnectEvent : USBEvent

@end
