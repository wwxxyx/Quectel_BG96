//
//  EightPinHardwareEvent.h
//  ATSMacApp
//
//  Created by Mark Hamlin on 8/2/12.
//  Copyright (c) 2012 Apple Inc. All rights reserved.
//

#import <CaptureKit/CaptureEvent.h>

@interface EightPinHardwareEvent : CaptureEvent

@end
