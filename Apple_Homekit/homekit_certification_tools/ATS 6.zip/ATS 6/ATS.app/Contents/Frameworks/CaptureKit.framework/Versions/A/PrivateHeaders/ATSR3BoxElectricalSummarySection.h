//
//  ATSR3BoxElectricalSummarySection.h
//  ATSMacApp
//
//  Created by Mark Hamlin on 8/15/12.
//  Copyright (c) 2012 Apple Inc. All rights reserved.
//

#import <CaptureKit/SummarySection.h>

@interface ATSR3BoxElectricalSummarySection : SummarySection

@end
