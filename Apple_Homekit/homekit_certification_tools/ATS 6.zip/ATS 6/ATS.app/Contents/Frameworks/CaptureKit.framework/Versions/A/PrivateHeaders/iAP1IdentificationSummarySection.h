//
//  iAP1IdentificationSummarySection.h
//  ATSMacApp
//
//  Created by Mark Hamlin on 8/13/12.
//  Copyright (c) 2012 Apple Inc. All rights reserved.
//

#import <CaptureKit/SummarySection.h>

@interface iAP1IdentificationSummarySection : SummarySection

@end
