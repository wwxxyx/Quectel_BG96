SDK Support readme
------------------

MobileDevices
This folder contains the header files for the MobileDevices.framework. They were copied from the MacOSX10.12.Internal.sdk.
The non-internal SDK does not contain header files to build against.

openssl
This folder contains the header files for the openssl library. They were copied from the MacOSX10.12.Internal.sdk.
The MobileDevices headers require headers from this project to build.
The non-internal SDK does not contain header files to build against.

