#ifndef STDBOOL_H
#define STDBOOL_H

typedef unsigned char bool;
#define false 0
#define true 1

#endif
