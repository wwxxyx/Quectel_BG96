// Workaround to include stdint.h.
#include <stdint-gcc.h>
